#ifndef __OLED_H
#define __OLED_H

#include "i2c.h"

/* OLED�����ú��� */
void OLED_Set_Pos(uint8_t x, uint8_t y);
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Clear(void);
void OLED_On(void);


//my_oled
void character_led(uint8_t x, uint8_t y);
//8����ҳ
void character_led8x16(uint8_t x, uint8_t y,char charindex);
//6��һҳ
void character_led6x8(uint8_t x, uint8_t y,char charindex);
void OLED_ShowBNum(uint8_t x,uint8_t y,float num,uint8_t len,uint8_t size2);//len:��С���㡢�������ݸ���
void OLED_ShowFloat(uint8_t x,uint8_t y,float num, uint8_t len, uint8_t size2);

/* OLED���ܺ��� */
void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t chr,uint8_t size);
void OLED_ShowNum(uint8_t x,uint8_t y,uint32_t num,uint8_t len,uint8_t size);
void OLED_ShowString(uint8_t x,uint8_t y, char *chr,uint8_t size);	 
void OLED_ShowCHinese(uint8_t x,uint8_t y,uint8_t no);
void OLED_DrawBMP(uint8_t x0, uint8_t y0,uint8_t x1, uint8_t y1,uint8_t BMP[]);

void my_led(uint8_t dat);

/* OLED��ʼ�� */
void OLED_Init(void);

#endif  
